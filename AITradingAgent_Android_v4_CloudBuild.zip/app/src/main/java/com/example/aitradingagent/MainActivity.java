package com.example.aitradingagent;
import android.app.*; import android.os.*; import android.view.*; import android.widget.*;
import java.io.*; import java.net.*; import java.util.concurrent.*;

public class MainActivity extends Activity {
 final String BASE_URL="http://10.0.2.2:8000/"; Spinner asset; TextView out; EditText capital,risk,qty; ExecutorService pool=Executors.newSingleThreadExecutor();
 TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setPadding(12,8,12,8);return t;}
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(16,16,16,16);
 x.addView(tv("AI Trading Agent v4")); asset=new Spinner(this);asset.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"BTC-USD","ETH-USD","AAPL","TSLA","SPY","GLD"}));x.addView(asset);
 capital=new EditText(this);capital.setHint("رأس المال الافتراضي");x.addView(capital);
 risk=new EditText(this);risk.setHint("المخاطرة %");x.addView(risk);qty=new EditText(this);qty.setHint("كمية Paper Trading");x.addView(qty);
 Button a=new Button(this);a.setText("تحليل");x.addView(a);Button c=new Button(this);c.setText("الشموع والمؤشرات");x.addView(c);
 Button bt=new Button(this);bt.setText("Backtest");x.addView(bt);Button pt=new Button(this);pt.setText("تسجيل صفقة Paper");x.addView(pt);
 out=tv("جاهز — لا يوجد تنفيذ حقيقي.");x.addView(out,new LinearLayout.LayoutParams(-1,0,1));setContentView(x);
 a.setOnClickListener(v->call("/signal/"+asset.getSelectedItem(),0)); c.setOnClickListener(v->call("/indicators/"+asset.getSelectedItem(),1));
 bt.setOnClickListener(v->call("/backtest/"+asset.getSelectedItem(),2)); pt.setOnClickListener(v->paper());}
 void call(String p,int mode){out.setText("جارٍ الاتصال...");pool.submit(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(BASE_URL+p).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(30000);BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String z;while((z=r.readLine())!=null)s.append(z);runOnUiThread(()->out.setText(format(s.toString(),mode)));}catch(Exception e){runOnUiThread(()->out.setText("خطأ: "+e.getMessage()));}});}
 void paper(){String q=qty.getText().toString();if(q.isEmpty())q="1";String t=(String)asset.getSelectedItem();call("/signal/"+t,3);}
 String format(String s,int mode){return s.replace("{","").replace("}","").replace("\"","").replace(",","\n").replace(":[",":\n");}
}