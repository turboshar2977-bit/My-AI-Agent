from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import yfinance as yf, pandas as pd, numpy as np, requests, sqlite3, time
from sklearn.ensemble import HistGradientBoostingClassifier

app=FastAPI(title="AI Trading Agent v4")
DB="paper.db"

def db():
    c=sqlite3.connect(DB)
    c.execute("""create table if not exists trades(
        id integer primary key, ts real, ticker text, side text,
        qty real, price real, pnl real default 0)""")
    c.commit(); return c

def rsi(s,n=14):
    d=s.diff(); up=d.clip(lower=0).rolling(n).mean(); dn=(-d.clip(upper=0)).rolling(n).mean()
    return 100-100/(1+up/(dn+1e-9))

def data(ticker,period="2y"):
    d=yf.download(ticker,period=period,interval="1d",auto_adjust=True,progress=False)
    if d.empty: raise ValueError("No market data")
    if isinstance(d.columns,pd.MultiIndex): d.columns=d.columns.get_level_values(0)
    d=d.dropna().copy(); d["ret1"]=d.Close.pct_change()
    d["sma10"]=d.Close.rolling(10).mean()/d.Close-1
    d["sma30"]=d.Close.rolling(30).mean()/d.Close-1
    d["vol20"]=d.ret1.rolling(20).std(); d["rsi14"]=rsi(d.Close)
    tr=pd.concat([d.High-d.Low,(d.High-d.Close.shift()).abs(),(d.Low-d.Close.shift()).abs()],axis=1).max(axis=1)
    d["atr14"]=tr.rolling(14).mean()
    d["volz"]=(d.Volume-d.Volume.rolling(20).mean())/(d.Volume.rolling(20).std()+1e-9)
    d["target"]=(d.Close.shift(-1)>d.Close).astype(int)
    return d.dropna()

FEATS=["ret1","sma10","sma30","vol20","rsi14","atr14","volz"]

def prediction(d):
    X=d[FEATS].replace([np.inf,-np.inf],np.nan).dropna(); y=d.loc[X.index,"target"]
    cut=max(60,int(len(X)*.8))
    m=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=15,random_state=42)
    m.fit(X.iloc[:cut],y.iloc[:cut]); p=float(m.predict_proba(X.iloc[[-1]])[0,1])
    last=d.iloc[-1]; price=float(last.Close); atr=float(last.atr14)
    sig="BUY" if p>=.62 else ("SELL" if p<=.38 else "HOLD")
    sl=price-1.5*atr if sig=="BUY" else (price+1.5*atr if sig=="SELL" else None)
    tp=price+3*atr if sig=="BUY" else (price-3*atr if sig=="SELL" else None)
    return {"signal":sig,"prob_up":round(p,4),"confidence":round(abs(p-.5)*2,4),
            "price":round(price,6),"atr":round(atr,6),"stop_loss":None if sl is None else round(sl,6),
            "take_profit":None if tp is None else round(tp,6),"training_rows":len(X)}

def get_news(ticker):
    try:
        q=requests.get("https://api.gdeltproject.org/api/v2/doc/doc",
          params={"query":ticker,"mode":"artlist","maxrecords":8,"format":"json","sort":"datedesc"},timeout=10).json()
        return [{"title":a.get("title",""),"url":a.get("url","")} for a in q.get("articles",[])]
    except: return []

@app.get("/health")
def health(): return {"ok":True,"version":"v4"}

@app.get("/signal/{ticker}")
def signal(ticker):
    try:
        d=data(ticker); out=prediction(d); out.update({"ticker":ticker,"news":get_news(ticker)})
        return out
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/indicators/{ticker}")
def indicators(ticker):
    try:
        d=data(ticker)
        rows=d.tail(60)
        return {"ticker":ticker,"candles":[
          {"date":str(i.date()),"open":round(float(r.Open),4),"high":round(float(r.High),4),
           "low":round(float(r.Low),4),"close":round(float(r.Close),4),"volume":int(r.Volume),
           "rsi":round(float(r.rsi14),2)} for i,r in rows.iterrows()]}
    except Exception as e: raise HTTPException(400,str(e))

class Trade(BaseModel):
    ticker:str; side:str; qty:float; price:float; pnl:float=0

@app.post("/paper/trade")
def paper_trade(t:Trade):
    if t.side not in ("BUY","SELL"): raise HTTPException(400,"side must be BUY or SELL")
    c=db(); c.execute("insert into trades(ts,ticker,side,qty,price,pnl) values(?,?,?,?,?,?)",
                      (time.time(),t.ticker,t.side,t.qty,t.price,t.pnl)); c.commit(); c.close()
    return {"ok":True}

@app.get("/paper/trades")
def paper_trades():
    c=db(); rows=c.execute("select id,ts,ticker,side,qty,price,pnl from trades order by id desc limit 50").fetchall(); c.close()
    return {"trades":[dict(id=r[0],ts=r[1],ticker=r[2],side=r[3],qty=r[4],price=r[5],pnl=r[6]) for r in rows]}

@app.get("/backtest/{ticker}")
def backtest(ticker:str,threshold:float=.60):
    d=data(ticker); X=d[FEATS].replace([np.inf,-np.inf],np.nan).dropna(); y=d.loc[X.index,"target"]
    cut=max(80,int(len(X)*.7)); m=HistGradientBoostingClassifier(max_iter=160,learning_rate=.05,max_leaf_nodes=15,random_state=42)
    m.fit(X.iloc[:cut],y.iloc[:cut]); p=m.predict_proba(X.iloc[cut:])[:,1]
    rets=d.loc[X.index].iloc[cut:].ret1.values; pos=np.where(p>=threshold,1,np.where(p<=1-threshold,-1,0))
    strat=pos*rets; eq=np.cumprod(1+np.nan_to_num(strat)); peak=np.maximum.accumulate(eq); dd=eq/peak-1
    trades=int(np.count_nonzero(pos)); wins=int(np.count_nonzero(strat>0))
    return {"ticker":ticker,"test_rows":len(strat),"trades":trades,
            "return_pct":round((eq[-1]-1)*100,2),"win_rate_pct":round(wins/max(trades,1)*100,2),
            "max_drawdown_pct":round(dd.min()*100,2)}
