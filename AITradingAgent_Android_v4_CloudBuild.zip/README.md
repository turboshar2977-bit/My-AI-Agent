# AI Trading Agent Android v4
نسخة متقدمة للبحث وPaper Trading.
الجديد: مؤشرات/بيانات شموع، Backtest، Stop Loss/Take Profit، قاعدة بيانات SQLite لصفقات Paper، سجل تداول عبر API.
لا يوجد تنفيذ حقيقي للأموال.
للتشغيل: شغّل backend ثم افتح المشروع في Android Studio.
Emulator: http://10.0.2.2:8000/
هاتف حقيقي على نفس الشبكة: غيّر BASE_URL إلى IP الكمبيوتر.

## بناء APK من الهاتف فقط عبر GitHub Actions
1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات هذا المشروع إليه.
3. افتح تبويب **Actions** وشغّل **Build Android APK**.
4. بعد نجاح البناء افتح الـworkflow ثم **Artifacts** وحمّل `AITradingAgent-v4-debug`.
5. فك الضغط عن ملف الـArtifact وستجد `app-debug.apk`.
6. افتح APK على هاتف Samsung A15 واسمح بالتثبيت من المصدر الذي استخدمتَه إذا طلب Android ذلك.

ملاحظة: هذا يبني APK للتجربة. الـBackend الخاص بالنظام يجب أن يكون متاحًا على الإنترنت حتى تعمل إشارات السوق والأخبار؛ عنوان 10.0.2.2 يعمل للمحاكي وليس للهاتف الحقيقي.
